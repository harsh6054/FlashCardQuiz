package com.example.flashcardquiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView tvQuestionAnswer;
    private Button btnPrev, btnNext, btnShowAnswer, btnAdd, btnEdit, btnDelete;

    private ArrayList<Flashcard> flashcards;
    private int currentIndex = 0;
    private boolean showingAnswer = false;

    // Colors for flashcards
    private int[] colors = {
            0xFFFFCDD2, // light red
            0xFFC8E6C9, // light green
            0xFFBBDEFB, // light blue
            0xFFFFF9C4, // light yellow
            0xFFD1C4E9  // light purple
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvQuestionAnswer = findViewById(R.id.tvQuestionAnswer);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnShowAnswer = findViewById(R.id.btnShowAnswer);
        btnAdd = findViewById(R.id.btnAdd);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        // Initialize flashcards
        flashcards = new ArrayList<>();
        flashcards.add(new Flashcard("What is Java?", "Java is a programming language."));
        flashcards.add(new Flashcard("What is Android?", "Android is a mobile operating system."));

        displayCurrentFlashcard();

        btnShowAnswer.setOnClickListener(v -> toggleAnswer());

        btnNext.setOnClickListener(v -> {
            if (!flashcards.isEmpty()) {
                currentIndex = (currentIndex + 1) % flashcards.size();
                showingAnswer = false;
                displayCurrentFlashcard();
            }
        });

        btnPrev.setOnClickListener(v -> {
            if (!flashcards.isEmpty()) {
                currentIndex = (currentIndex - 1 + flashcards.size()) % flashcards.size();
                showingAnswer = false;
                displayCurrentFlashcard();
            }
        });

        btnAdd.setOnClickListener(v -> showAddEditDialog(null));

        btnEdit.setOnClickListener(v -> {
            if (!flashcards.isEmpty()) {
                showAddEditDialog(flashcards.get(currentIndex));
            } else {
                Toast.makeText(this, "No flashcards to edit", Toast.LENGTH_SHORT).show();
            }
        });

        btnDelete.setOnClickListener(v -> {
            if (!flashcards.isEmpty()) {
                flashcards.remove(currentIndex);
                if (flashcards.isEmpty()) {
                    tvQuestionAnswer.setText("No flashcards available");
                    tvQuestionAnswer.setBackgroundColor(0xFFFFFFFF);
                } else {
                    currentIndex = currentIndex % flashcards.size();
                    showingAnswer = false;
                    displayCurrentFlashcard();
                }
            } else {
                Toast.makeText(this, "No flashcards to delete", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayCurrentFlashcard() {
        if (!flashcards.isEmpty()) {
            Flashcard card = flashcards.get(currentIndex);
            tvQuestionAnswer.setText(showingAnswer ? card.getAnswer() : card.getQuestion());

            // Random background color
            int color = colors[(int) (Math.random() * colors.length)];
            tvQuestionAnswer.setBackgroundColor(color);
        } else {
            tvQuestionAnswer.setText("No flashcards available");
            tvQuestionAnswer.setBackgroundColor(0xFFFFFFFF);
        }
    }

    private void toggleAnswer() {
        if (!flashcards.isEmpty()) {
            showingAnswer = !showingAnswer;
            displayCurrentFlashcard();
        }
    }

    private void showAddEditDialog(Flashcard cardToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(cardToEdit == null ? "Add Flashcard" : "Edit Flashcard");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        final EditText inputQuestion = new EditText(this);
        inputQuestion.setHint("Question");
        inputQuestion.setInputType(InputType.TYPE_CLASS_TEXT);
        layout.addView(inputQuestion);

        final EditText inputAnswer = new EditText(this);
        inputAnswer.setHint("Answer");
        inputAnswer.setInputType(InputType.TYPE_CLASS_TEXT);
        layout.addView(inputAnswer);

        if (cardToEdit != null) {
            inputQuestion.setText(cardToEdit.getQuestion());
            inputAnswer.setText(cardToEdit.getAnswer());
        }

        builder.setView(layout);

        builder.setPositiveButton(cardToEdit == null ? "Add" : "Save", (dialog, which) -> {
            String question = inputQuestion.getText().toString().trim();
            String answer = inputAnswer.getText().toString().trim();
            if (!question.isEmpty() && !answer.isEmpty()) {
                if (cardToEdit == null) {
                    flashcards.add(new Flashcard(question, answer));
                    currentIndex = flashcards.size() - 1;
                } else {
                    cardToEdit.setQuestion(question);
                    cardToEdit.setAnswer(answer);
                }
                showingAnswer = false;
                displayCurrentFlashcard();
            } else {
                Toast.makeText(this, "Question and Answer cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
